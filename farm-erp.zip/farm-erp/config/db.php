<?php
$host = "localhost";
$dbname = "u975109235_farm_erp";
$username = "u975109235_farm_erp";
$password = "q880~wKH58T=";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>
