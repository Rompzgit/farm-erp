<?php
session_start();

// Hardcoded credentials
$valid_email = "admin@example.com";
$valid_password = "111";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if ($email === $valid_email && $password === $valid_password) {
        $_SESSION['user'] = $email;
        header("Location: pages/dashboard.php");
        exit();
    } else {
        $error = "Invalid email or password!";
    }
}

include 'includes/header.php';
?>

<style>
    .login-wrapper {
        min-height: calc(100vh - 70px); /* Adjust for header & footer */
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f8f9fa;
    }

    .login-card {
        width: 380px;
        border-radius: 12px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }

    footer {
        position: absolute;
        bottom: 0;
        width: 100%;
    }
</style>

<div class="login-wrapper">
    <div class="card p-4 login-card">
        <div class="text-center mb-3">
            <img src="assets/logo.png" alt="Logo" height="50">
        </div>
        <h4 class="text-center mb-4">Sign In</h4>
        <?php if (isset($error)) echo "<div class='alert alert-danger text-center'>$error</div>"; ?>
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Email Address</label>
                <input type="email" name="email" class="form-control form-control-lg" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control form-control-lg" required>
            </div>
            <button type="submit" class="btn btn-success w-100 py-2">Sign In</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
