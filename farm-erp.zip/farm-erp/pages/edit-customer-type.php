<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

$id = $_GET['id'];
$customer_type = $conn->query("SELECT * FROM customer_types WHERE id = $id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $type_name = $_POST['type_name'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE customer_types SET type_name = ?, description = ? WHERE id = ?");
    $stmt->bind_param("ssi", $type_name, $description, $id);

    if ($stmt->execute()) {
        header("Location: masters.php");
        exit();
    } else {
        $error = "Error updating customer type!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Edit Customer Type</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Customer Type</label>
                <select name="type_name" class="form-select" required>
                    <option value="Regular" <?= ($customer_type['type_name'] == 'Regular') ? 'selected' : '' ?>>Regular</option>
                    <option value="Staff" <?= ($customer_type['type_name'] == 'Staff') ? 'selected' : '' ?>>Staff</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"><?= $customer_type['description'] ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary w-100">Update Customer Type</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
