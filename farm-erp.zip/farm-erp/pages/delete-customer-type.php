<?php
session_start();
include '../config/db.php';

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM customer_types WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: masters.php");
    exit();
} else {
    echo "Error deleting customer type.";
}
?>
