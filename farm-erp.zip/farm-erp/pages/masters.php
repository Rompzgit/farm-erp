<?php
session_start();
include '../config/db.php';
include '../includes/header.php';
?>

<div class="container mt-4">
    <h3 class="mb-4">Masters</h3>
    
    <!-- Payment Modes -->
    <div class="card p-4 mb-3 shadow-sm">
        <h5>Payment Modes</h5>
        <a href="add-payment-mode.php" class="btn btn-primary mb-3">Add New Payment Mode</a>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Mode Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM payment_modes");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['mode_name']}</td>
                            <td>{$row['description']}</td>
                            <td>
                                <a href='edit-payment-mode.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete-payment-mode.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- User Access -->
    <div class="card p-4 mb-3 shadow-sm">
        <h5>User Access</h5>
        <a href="add-user-access.php" class="btn btn-primary mb-3">Add New Role</a>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Role Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM user_access");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['role_name']}</td>
                            <td>{$row['description']}</td>
                            <td>
                                <a href='edit-user-access.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete-user-access.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Milk Rates -->
    <div class="card p-4 mb-3 shadow-sm">
        <h5>Milk Rates</h5>
        <a href="add-milk-rate.php" class="btn btn-primary mb-3">Add New Milk Rate</a>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Milk Type</th>
                    <th>Rate</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM milk_rates");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['milk_type']}</td>
                            <td>{$row['rate']}</td>
                            <td>
                                <a href='edit-milk-rate.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete-milk-rate.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Customer Types -->
    <div class="card p-4 mb-3 shadow-sm">
        <h5>Customer Types</h5>
        <a href="add-customer-type.php" class="btn btn-primary mb-3">Add New Customer Type</a>
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Type Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $result = $conn->query("SELECT * FROM customer_types");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['type_name']}</td>
                            <td>{$row['description']}</td>
                            <td>
                                <a href='edit-customer-type.php?id={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                <a href='delete-customer-type.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
