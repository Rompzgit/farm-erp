<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../config/db.php';
include '../includes/header.php';

// Ensure employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header('Location: employee-login.php');
    exit();
}

// Get employee details from session
$employee_id = $_SESSION['employee_id'];
$employee_name = $_SESSION['user_name'];
$employee_role = $_SESSION['user_role'];

// Get session type (morning/evening) and supply date
$session_type = isset($_POST['session_type']) ? $_POST['session_type'] : 'morning'; // Default to morning
$supply_date = isset($_POST['supply_date']) ? $_POST['supply_date'] : date('Y-m-d'); // Default to today's date

// Fetch the list of customers from the 'customers' table
$customers = $conn->query("SELECT * FROM customers WHERE status = 'active' ORDER BY customer_name ASC");

// Get the total count of customers
$total_customers = $customers->num_rows;

// Check for existing milk supply entries for this date and session
$entries = [];
while ($customer = $customers->fetch_assoc()) {
    $customer_id = $customer['id'];
    $query = "SELECT * FROM milk_supply WHERE customer_id = ? AND session_type = ? AND supply_date = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iss", $customer_id, $session_type, $supply_date);
    $stmt->execute();
    $result = $stmt->get_result();

    // If entry exists, store it to prevent re-entry
    if ($result->num_rows > 0) {
        $entries[] = $customer_id;
    }
}

// If there's no session selected, display an error message
if (!$session_type) {
    $error_message = "Please select a valid session (Morning or Evening).";
}
?>

<!-- Dashboard HTML -->
<div class="container mt-4">
    <h3>Enter Milk Supply</h3>
    <h5>Date: <?= $supply_date ?> | Session: <?= ucfirst($session_type) ?> | Employee: <?= $employee_name ?> (Role: <?= ucfirst($employee_role) ?>)</h5>

    <!-- Session Selection -->
    <div class="mb-3">
        <label for="session_type" class="form-label">Choose Session</label>
        <select id="session_type" name="session_type" class="form-select" onchange="this.form.submit()">
            <option value="morning" <?= ($session_type == 'morning') ? 'selected' : ''; ?>>Morning</option>
            <option value="evening" <?= ($session_type == 'evening') ? 'selected' : ''; ?>>Evening</option>
        </select>
    </div>

    <!-- Milk Supply Entry Form -->
    <form method="POST" action="save_milk_supply.php">
        <input type="hidden" name="supply_date" value="<?= $supply_date ?>">
        <input type="hidden" name="session_type" value="<?= $session_type ?>">

        <div id="customer-form-container">
            <?php
            $customer_count = 0;
            while ($customer = $customers->fetch_assoc()) {
                $customer_count++;
                $customer_id = $customer['id'];
                $is_disabled = in_array($customer_id, $entries) ? 'disabled' : ''; // Disable if already entered
                ?>

                <div class="customer-form mb-3">
                    <h5><?= $customer['customer_name'] ?> (<?= $customer['customer_type'] ?>)</h5>
                    <div class="form-group">
                        <label>Liters Supplied</label>
                        <select name="liters[<?= $customer_id ?>]" class="form-control" <?= $is_disabled ?>>
                            <option value="0">Not Supplied</option>
                            <option value="0.5">0.5 Liters</option>
                            <option value="1">1 Liter</option>
                            <option value="1.5">1.5 Liters</option>
                            <option value="2">2 Liters</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <button type="button" class="btn btn-secondary" onclick="goToNextCustomer(<?= $customer_count ?>)">Next</button>
                        <?php if ($customer_count > 1) { ?>
                            <button type="button" class="btn btn-secondary" onclick="goToPreviousCustomer(<?= $customer_count ?>)">Back</button>
                        <?php } ?>
                    </div>
                </div>

            <?php } ?>

            <div class="progress-bar">
                <progress value="<?= $customer_count ?>" max="<?= $total_customers ?>"></progress>
                <p>Entered: <?= $customer_count ?> / Pending: <?= $total_customers - $customer_count ?></p>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-success" onclick="return confirm('Are you sure you want to submit?')">Confirm & Submit</button>
        </div>
    </form>
</div>

<script>
// JavaScript for handling next/back button and progress bar updates
function goToNextCustomer(current) {
    document.getElementById('customer-form-container').scrollTo(0, current * 200); // Scroll to next customer
}

function goToPreviousCustomer(current) {
    document.getElementById('customer-form-container').scrollTo(0, (current - 1) * 200); // Scroll to previous customer
}
</script>

<?php include '../includes/footer.php'; ?>
