<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $customer_type = $_POST['customer_type'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("INSERT INTO customers (name, customer_type, phone, address) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $customer_type, $phone, $address);

    if ($stmt->execute()) {
        $success_message = "Customer added successfully!";
    } else {
        $error_message = "Error adding customer!";
    }
}

$customer_types = $conn->query("SELECT * FROM customer_types");
?>

<div class="container mt-4">
    <h3 class="mb-4">Add New Customer</h3>
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?= $success_message; ?></div>
    <?php elseif (isset($error_message)): ?>
        <div class="alert alert-danger"><?= $error_message; ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Customer Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Customer Type</label>
            <select name="customer_type" class="form-select" required>
                <?php while ($row = $customer_types->fetch_assoc()): ?>
                    <option value="<?= $row['type_name']; ?>"><?= $row['type_name']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea name="address" class="form-control" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Add Customer</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
