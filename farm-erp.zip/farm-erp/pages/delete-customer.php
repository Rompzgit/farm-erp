<?php
session_start();
include '../config/db.php';

$id = $_GET['id'];

$stmt = $conn->prepare("DELETE FROM customers WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: customers.php?success=Customer deleted successfully");
} else {
    header("Location: customers.php?error=Error deleting customer");
}
