<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

$id = $_GET['id'];
$milk_rate = $conn->query("SELECT * FROM milk_rates WHERE id = $id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $milk_type = $_POST['milk_type'];
    $rate = $_POST['rate'];

    $stmt = $conn->prepare("UPDATE milk_rates SET milk_type = ?, rate = ? WHERE id = ?");
    $stmt->bind_param("sdi", $milk_type, $rate, $id);

    if ($stmt->execute()) {
        header("Location: masters.php");
        exit();
    } else {
        $error = "Error updating milk rate!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Edit Milk Rate (per litre in INR)</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Milk Type</label>
                <input type="text" name="milk_type" class="form-control" value="<?= $milk_rate['milk_type'] ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Rate (per litre in INR)</label>
                <input type="number" name="rate" class="form-control" step="0.01" value="<?= $milk_rate['rate'] ?>" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Update Milk Rate</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
