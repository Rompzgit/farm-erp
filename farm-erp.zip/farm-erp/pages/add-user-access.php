<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $role_name = $_POST['role_name'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO user_access (role_name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $role_name, $description);

    if ($stmt->execute()) {
        header("Location: masters.php");
        exit();
    } else {
        $error = "Error adding user role!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Add User Role</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Role Name</label>
                <input type="text" name="role_name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"></textarea>
            </div>

            <button type="submit" class="btn btn-primary w-100">Add User Role</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
