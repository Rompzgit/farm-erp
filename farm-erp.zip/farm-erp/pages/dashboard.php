<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../index.php");
    exit();
}

include '../includes/header.php';
?>

<style>
    .dashboard-container {
        padding: 20px;
    }

    .dashboard-card {
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    }

    .quick-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
    }

    .quick-actions .btn {
        flex: 1;
        min-width: 100px;
    }
</style>

<div class="container dashboard-container">
    <h3 class="mb-3">Dashboard</h3>

    <!-- Overview Cards -->
    <div class="row">
        <div class="col-6 col-md-3 mb-3">
            <div class="card dashboard-card bg-success text-white text-center">
                <h5>Customers</h5>
                <h2>120</h2>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card dashboard-card bg-primary text-white text-center">
                <h5>Milk (Ltrs)</h5>
                <h2>500</h2>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card dashboard-card bg-warning text-dark text-center">
                <h5>Payments Due</h5>
                <h2>₹15,000</h2>
            </div>
        </div>
        <div class="col-6 col-md-3 mb-3">
            <div class="card dashboard-card bg-danger text-white text-center">
                <h5>Pending Orders</h5>
                <h2>8</h2>
            </div>
        </div>
    </div>

    <!-- Quick Actions -->
    <h5 class="mt-4">Quick Actions</h5>
    <div class="quick-actions">
        <a href="masters.php" class="btn btn-success">Manage Masters</a>
        <a href="users.php" class="btn btn-primary">Manage Employees</a>
        <a href="customers.php" class="btn btn-warning">Manage Customers</a>
        <a href="users.php" class="btn btn-info">Manage Employees</a> <!-- New Button -->
        <a href="masters.php" class="btn btn-info">Masters</a> <!-- New Button -->

    </div>

    <!-- Recent Activity -->
    <h5 class="mt-4">Recent Activity</h5>
    <ul class="list-group">
        <li class="list-group-item">Milk Entry: 250L - Morning Shift</li>
        <li class="list-group-item">Payment Received: ₹5000 from Ram Dairy</li>
        <li class="list-group-item">New Customer Added: Shyam Milk Suppliers</li>
    </ul>
</div>

<?php include '../includes/footer.php'; ?>
