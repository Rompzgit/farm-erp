<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

$id = $_GET['id'];
$customer = $conn->query("SELECT * FROM customers WHERE id = $id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $customer_type = $_POST['customer_type'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $stmt = $conn->prepare("UPDATE customers SET name = ?, customer_type = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->bind_param("sssss", $name, $customer_type, $phone, $address, $id);

    if ($stmt->execute()) {
        $success_message = "Customer updated successfully!";
    } else {
        $error_message = "Error updating customer!";
    }
}

$customer_types = $conn->query("SELECT * FROM customer_types");
?>

<div class="container mt-4">
    <h3 class="mb-4">Edit Customer</h3>
    <?php if (isset($success_message)): ?>
        <div class="alert alert-success"><?= $success_message; ?></div>
    <?php elseif (isset($error_message)): ?>
        <div class="alert alert-danger"><?= $error_message; ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Customer Name</label>
            <input type="text" name="name" class="form-control" value="<?= $customer['name']; ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Customer Type</label>
            <select name="customer_type" class="form-select" required>
                <?php while ($row = $customer_types->fetch_assoc()): ?>
                    <option value="<?= $row['type_name']; ?>" <?= ($customer['customer_type'] == $row['type_name']) ? 'selected' : ''; ?>><?= $row['type_name']; ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label class="form-label">Phone</label>
            <input type="text" name="phone" class="form-control" value="<?= $customer['phone']; ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Address</label>
            <textarea name="address" class="form-control" required><?= $customer['address']; ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Update Customer</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
