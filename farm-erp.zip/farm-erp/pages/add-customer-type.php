<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $type_name = $_POST['type_name'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO customer_types (type_name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $type_name, $description);

    if ($stmt->execute()) {
        header("Location: masters.php");
        exit();
    } else {
        $error = "Error adding customer type!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Add Customer Type</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Customer Type</label>
                <select name="type_name" class="form-select" required>
                    <option value="Regular">Regular</option>
                    <option value="Staff">Staff</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"></textarea>
            </div>

            <button type="submit" class="btn btn-primary w-100">Add Customer Type</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
