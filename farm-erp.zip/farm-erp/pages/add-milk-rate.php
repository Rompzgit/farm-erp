<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $milk_type = $_POST['milk_type'];
    $rate = $_POST['rate'];

    $stmt = $conn->prepare("INSERT INTO milk_rates (milk_type, rate) VALUES (?, ?)");
    $stmt->bind_param("sd", $milk_type, $rate);

    if ($stmt->execute()) {
        header("Location: masters.php");
        exit();
    } else {
        $error = "Error adding milk rate!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Add Milk Rate (per litre in INR)</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Milk Type</label>
                <input type="text" name="milk_type" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Rate (per litre in INR)</label>
                <input type="number" name="rate" class="form-control" step="0.01" required>
            </div>

            <button type="submit" class="btn btn-primary w-100">Add Milk Rate</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
