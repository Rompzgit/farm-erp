<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: ../index.php");
    exit();
}

include '../config/db.php';
include '../includes/header.php';

// Fetch users from the database
$result = $conn->query("SELECT * FROM users");
?>

<div class="container mt-4">
    <h3 class="mb-4">Manage Employees</h3>

    <!-- Success Message Alert -->
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <?= $_SESSION['success_message']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    <!-- Add Employee Button -->
    <div class="d-flex justify-content-between mb-3">
        <a href="add-user.php" class="btn btn-success"><i class="bi bi-plus-circle"></i> Add Employee</a>
    </div>

    <!-- Employee Table -->
    <div class="card p-3 shadow-sm">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td>
                            <span class="badge bg-<?= ($row['role'] == 'admin') ? 'primary' : 'secondary'; ?>">
                                <?= ucfirst($row['role']) ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit-user.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">
                                <i class="bi bi-pencil"></i> Edit
                            </a>
                            <button onclick="confirmDelete(<?= $row['id']; ?>)" class="btn btn-sm btn-danger">
                                <i class="bi bi-trash"></i> Delete
                            </button>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Delete Confirmation Script -->
<script>
function confirmDelete(id) {
    if (confirm("Are you sure you want to delete this user?")) {
        window.location.href = "delete-user.php?id=" + id;
    }
}
</script>

<?php include '../includes/footer.php'; ?>
