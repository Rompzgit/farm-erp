<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

$id = $_GET['id'];
$payment_mode = $conn->query("SELECT * FROM payment_modes WHERE id = $id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $mode_name = $_POST['mode_name'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE payment_modes SET mode_name = ?, description = ? WHERE id = ?");
    $stmt->bind_param("ssi", $mode_name, $description, $id);

    if ($stmt->execute()) {
        header("Location: masters.php");
        exit();
    } else {
        $error = "Error updating payment mode!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Edit Payment Mode</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Mode Name</label>
                <input type="text" name="mode_name" class="form-control" value="<?= $payment_mode['mode_name'] ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"><?= $payment_mode['description'] ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary w-100">Update Payment Mode</button>
        </form>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
