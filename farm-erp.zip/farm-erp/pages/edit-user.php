<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

// Get user ID from the URL
$id = $_GET['id'];

// Fetch user data from the database
$user = $conn->query("SELECT * FROM users WHERE id = $id")->fetch_assoc();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $role = $_POST['role'];
    $new_password = $_POST['new_password'];

    // Prepare the SQL query for updating the user
    if (!empty($new_password)) {
        // Update with the new password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET name = ?, role = ?, password = ? WHERE id = ?");
        $stmt->bind_param("sssi", $name, $role, $hashed_password, $id);
    } else {
        // Update without changing the password
        $stmt = $conn->prepare("UPDATE users SET name = ?, role = ? WHERE id = ?");
        $stmt->bind_param("ssi", $name, $role, $id);
    }

    // Execute the query
    if ($stmt->execute()) {
        $_SESSION['success'] = "User updated successfully!";
        header("Location: edit-user.php?id=$id"); // Redirect to reload the page with success message
        exit();
    } else {
        $error = "Error updating user!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Edit Employee</h3>
    <div class="card p-4 shadow-sm">
        
        <!-- Display Success Message -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success d-flex justify-content-between align-items-center">
                <span><?= htmlspecialchars($_SESSION['success']) ?></span>
                <a href="users.php" class="btn btn-success btn-sm">Manage Employees</a>
            </div>
            <?php unset($_SESSION['success']); // Clear the success message after displaying ?>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>

            <div class="mb-3">
                <label class="form-label">New Password (Leave blank to keep current)</label>
                <div class="input-group">
                    <input type="password" id="newPassword" name="new_password" class="form-control">
                    <button type="button" class="btn btn-outline-secondary" onclick="toggleNewPassword()">
                        <i class="bi bi-eye" id="toggleNewIcon"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary" onclick="copyNewPassword()">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="admin" <?= ($user['role'] == 'admin') ? 'selected' : '' ?>>Admin</option>
                    <option value="employee" <?= ($user['role'] == 'employee') ? 'selected' : '' ?>>Employee</option>
                </select>
            </div>

            <button type="submit" class="btn btn-primary w-100">Update Employee</button>
        </form>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger mt-3">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function toggleNewPassword() {
    let passwordField = document.getElementById("newPassword");
    let toggleIcon = document.getElementById("toggleNewIcon");

    if (passwordField.type === "password") {
        passwordField.type = "text";
        toggleIcon.classList.replace("bi-eye", "bi-eye-slash");
    } else {
        passwordField.type = "password";
        toggleIcon.classList.replace("bi-eye-slash", "bi-eye");
    }
}

function copyNewPassword() {
    let passwordField = document.getElementById("newPassword");
    navigator.clipboard.writeText(passwordField.value);
    alert("Password copied!");
}
</script>

<?php include '../includes/footer.php'; ?>
