<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

$customers = $conn->query("SELECT * FROM customers");
?>

<div class="container mt-4">
    <!-- Header & Add Customer Button -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3 class="text-primary fw-bold">Manage Customers</h3>
        <a href="add-customer.php" class="btn btn-success btn-sm d-flex align-items-center">
            <i class="fas fa-plus me-1"></i> Add Customer
        </a>
    </div>

    <!-- Responsive Table -->
    <div class="table-responsive shadow-sm rounded">
        <table class="table table-bordered table-striped table-hover align-middle">
            <thead class="table-dark text-light">
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th class="text-center">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $customers->fetch_assoc()): ?>
                    <tr>
                        <td class="fw-bold"><?= htmlspecialchars($row['name']); ?></td>
                        <td>
                            <span class="badge bg-info"><?= htmlspecialchars($row['customer_type']); ?></span>
                        </td>
                        <td><?= htmlspecialchars($row['phone']); ?></td>
                        <td><?= htmlspecialchars($row['address']); ?></td>
                        <td class="text-center">
                            <a href="edit-customer.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="delete-customer.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
