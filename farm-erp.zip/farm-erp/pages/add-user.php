<?php
session_start();
include '../config/db.php';
include '../includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $role = $_POST['role'];

    $stmt = $conn->prepare("INSERT INTO users (name, password, role) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $password, $role);

    if ($stmt->execute()) {
        header("Location: users.php");
        exit();
    } else {
        $error = "Error adding user!";
    }
}
?>

<div class="container mt-4">
    <h3 class="mb-4">Add Employee</h3>
    <div class="card p-4 shadow-sm">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group">
                    <input type="password" id="password" name="password" class="form-control" required>
                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
                        <i class="bi bi-eye" id="toggleIcon"></i>
                    </button>
                    <button type="button" class="btn btn-outline-secondary" onclick="copyPassword()">
                        <i class="bi bi-clipboard"></i>
                    </button>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="admin">Admin</option>
                    <option value="employee">Employee</option>
                </select>
            </div>

            <button type="submit" class="btn btn-success w-100">Add Employee</button>
        </form>
    </div>
</div>

<script>
function togglePassword() {
    let passwordField = document.getElementById("password");
    let toggleIcon = document.getElementById("toggleIcon");

    if (passwordField.type === "password") {
        passwordField.type = "text";
        toggleIcon.classList.replace("bi-eye", "bi-eye-slash");
    } else {
        passwordField.type = "password";
        toggleIcon.classList.replace("bi-eye-slash", "bi-eye");
    }
}

function copyPassword() {
    let passwordField = document.getElementById("password");
    navigator.clipboard.writeText(passwordField.value);
    alert("Password copied!");
}
</script>


<?php include '../includes/footer.php'; ?>
