<footer class="text-center p-3 mt-4 bg-white shadow">
    <small>&copy; <?= date("Y") ?> Farm House ERP</small>
</footer>
</body>
</html>
